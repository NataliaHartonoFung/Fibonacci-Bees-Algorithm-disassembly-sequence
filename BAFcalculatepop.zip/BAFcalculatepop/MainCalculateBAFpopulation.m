%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% This matlab code helps the user calculate the total population or find  %
% combination of parameter settings for Fibonacci Bees Algorithm           %
% The minimum starting number for Fibonacci sequence is 1                 %
% Example of Fibonacci number are 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, ...  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The first option:                                                       %
% input: m, n and Fibonacci number; output: nr values and total population%
%                                                                         %
% The second option:                                                      %
% input: target population and m; output: all possible combination of     %
% parameters.                                                             %
%                                                                         %
% Option no 1 is useful for calculating the total population, while       %
% option 2 is useful for comparing with other population-based            %
% metaheuristics and finding all possible combination parameters for BAF  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all; close all;

UserInput;
